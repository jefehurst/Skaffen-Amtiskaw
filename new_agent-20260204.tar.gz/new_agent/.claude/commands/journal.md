---
description: Add entry to today's Logseq journal
---

Add the following to today's Logseq journal:

1. Use `mcp__logseq__addJournalContent`
2. Add under the `### Notes` heading
3. Format as bullet points with timestamp prefix
4. Include any relevant context or links

Content to add: $ARGUMENTS
