"""Configuration handling for ESM CLI."""

import os
from dataclasses import dataclass, field


@dataclass
class ESMConfig:
    """Configuration for ESM client.

    Configuration can be loaded from:
    1. Environment variables (ESM_URL, ESM_USER, ESM_PASSWORD)
    2. Explicit parameters
    3. Config file (future)

    SSL verification is disabled by default because ESM commonly uses
    self-signed certificates.
    """

    base_url: str = ""
    username: str = ""
    password: str = ""
    verify_ssl: bool = False
    timeout: int = 30
    esm_version: str | None = None

    # Session persistence (future)
    session_dir: str = field(default_factory=lambda: os.path.expanduser("~/.cache/esm-cli"))

    @classmethod
    def from_env(cls) -> "ESMConfig":
        """Load configuration from environment variables.

        Environment variables:
            ESM_URL: Base URL (e.g., https://esm.example.com:8081/admin)
            ESM_USER: Username
            ESM_PASSWORD: Password
            ESM_VERIFY_SSL: Set to "true" to enable SSL verification
            ESM_TIMEOUT: Request timeout in seconds
            ESM_VERSION: ESM version (for selector overrides)

        Returns:
            ESMConfig instance
        """
        return cls(
            base_url=os.environ.get("ESM_URL", ""),
            username=os.environ.get("ESM_USER", ""),
            password=os.environ.get("ESM_PASSWORD", ""),
            verify_ssl=os.environ.get("ESM_VERIFY_SSL", "").lower() == "true",
            timeout=int(os.environ.get("ESM_TIMEOUT", "30")),
            esm_version=os.environ.get("ESM_VERSION"),
        )

    def validate(self) -> list[str]:
        """Validate configuration, returning list of missing fields.

        Returns:
            List of missing required field names.
        """
        missing = []
        if not self.base_url:
            missing.append("base_url (ESM_URL)")
        if not self.username:
            missing.append("username (ESM_USER)")
        if not self.password:
            missing.append("password (ESM_PASSWORD)")
        return missing
