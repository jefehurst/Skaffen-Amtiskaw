"""ESM CLI - Ellucian Solution Manager automation."""

__version__ = "0.1.0"
