"""ESM CLI tests."""
