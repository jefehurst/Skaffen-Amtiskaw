runner-find: Search Runner Technologies support

USAGE: just runner-find "QUERY" PREREQ: just runner-login (check: just runner-status)

EX: just runner-find "CLEAN_Address configuration"

RELATED: runner-login, runner-status
