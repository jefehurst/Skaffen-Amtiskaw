ellucian-status: Check Ellucian session validity

USAGE: just ellucian-status OUTPUT: session info (success) or "expired"/"not logged in" (fail) ACTION: if expired → just
ellucian-login RELATED: ellucian-login, ellucian-keepalive
