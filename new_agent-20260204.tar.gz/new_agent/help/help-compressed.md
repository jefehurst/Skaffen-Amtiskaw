help: Show recipe documentation

USAGE: just help RECIPE LIST: just --list (all recipes) AGENT: just agenthelp RECIPE (token-compressed)

EX: just help ellucian-find
