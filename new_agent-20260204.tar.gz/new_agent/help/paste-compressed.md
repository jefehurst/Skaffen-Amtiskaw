paste: Upload file to paste.rs

USAGE: just paste FILE OUTPUT: URL + curl command

EX: just paste /tmp/debug.log STDIN: just paste-stdin (pipe content)

WARN: public service, no secrets RELATED: paste-stdin
