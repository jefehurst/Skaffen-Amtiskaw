`just sessions-mark ID [FINDINGS]` - Mark session as reviewed.

Args: SESSION_ID (required), FINDINGS count (default 0).

Updates `reflect/reviewed.tsv` with session ID, mtime, review date, findings.

Related: `sessions-pending`, `sessions-summary`, `analyze-sessions`.
