`just sessions-summary` - Show review stats: total, reviewed, pending counts.

Related: `sessions-pending` (list), `sessions-mark` (mark reviewed).
