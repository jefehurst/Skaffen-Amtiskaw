"""Son of Stibbons - AI Work Assistant with Logseq API extensions."""

__version__ = "0.1.0"
